let answer=0; let angleMode='DEG'; const window={}; const nativeAvailable=()=>false;
  const normalize = (s) => String(s)
    .replace(/×/g, '*').replace(/÷/g, '/').replace(/[−–]/g, '-')
    .replace(/π/g, 'pi').replace(/√/g, 'sqrt').replace(/,/g, ',');

  function tokenize(input) {
    const s = normalize(input);
    const out = [];
    let i = 0;
    while (i < s.length) {
      const c = s[i];
      if (/\s/.test(c)) { i++; continue; }
      if (/[0-9.]/.test(c)) {
        let j = i;
        while (j < s.length && /[0-9.]/.test(s[j])) j++;
        if (s.slice(i, j).split('.').length > 2) throw new Error('Nombre décimal invalide');
        if ((s[j] === 'e' || s[j] === 'E') && /[+\-0-9]/.test(s[j + 1] || '')) {
          j++;
          if (s[j] === '+' || s[j] === '-') j++;
          const expStart = j;
          while (j < s.length && /[0-9]/.test(s[j])) j++;
          if (expStart === j) throw new Error('Exposant invalide');
        }
        const n = Number(s.slice(i, j));
        if (!Number.isFinite(n)) throw new Error('Nombre non valide');
        out.push({ type: 'number', value: n }); i = j; continue;
      }
      if (/[a-zA-Z_]/.test(c)) {
        let j = i + 1;
        while (j < s.length && /[a-zA-Z_0-9]/.test(s[j])) j++;
        out.push({ type: 'ident', value: s.slice(i, j).toLowerCase() }); i = j; continue;
      }
      if ('+-*/^!%(),'.includes(c)) {
        out.push({ type: c === '(' || c === ')' || c === ',' ? c : 'op', value: c }); i++; continue;
      }
      throw new Error(`Symbole inconnu : ${c}`);
    }
    // Multiplication implicite : 2π, 3(4+1), (2)(3), 2sin(30).
    const functions = new Set(['sin','cos','tan','asin','acos','atan','atan2','sinh','cosh','tanh','asinh','acosh','atanh','ln','log','log2','sqrt','cbrt','abs','exp','floor','ceil','round','trunc','sign','factorial','fact','prime','isprime','gcd','pgcd','lcm','ppcm','hypot','ncr','npr','min','max','pow','root','mod','deg','rad']);
    const result = [];
    const endsValue = (t) => t && (t.type === 'number' || t.type === ')' || (t.type === 'op' && (t.value === '!' || t.value === '%')) || (t.type === 'ident' && !functions.has(t.value)));
    const startsValue = (t) => t && (t.type === 'number' || t.type === 'ident' || t.type === '(');
    for (let k = 0; k < out.length; k++) {
      const prev = out[k - 1], cur = out[k];
      if (k > 0 && endsValue(prev) && startsValue(cur)) result.push({ type: 'op', value: '*' });
      result.push(cur);
    }
    return result;
  }

  function factorial(x) {
    if (!Number.isInteger(x) || x < 0) throw new Error('n! exige un entier positif ou nul');
    if (x <= 20 && nativeAvailable()) {
      const n = window.NovaNative.factorial(String(x));
      if (n !== 'ERREUR') return Number(n);
    }
    if (x > 170) throw new Error('Résultat trop grand pour ce mode numérique');
    let v = 1;
    for (let n = 2; n <= x; n++) v *= n;
    return v;
  }
  function prime(x) {
    if (!Number.isSafeInteger(x)) throw new Error('prime(n) exige un entier sûr');
    if (nativeAvailable()) {
      const n = window.NovaNative.isPrime(String(x));
      if (n !== 'ERREUR') return Number(n);
    }
    if (x < 2) return 0;
    for (let i = 2; i <= x / i; i++) if (x % i === 0) return 0;
    return 1;
  }
  function gcd(a, b) {
    if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b)) throw new Error('pgcd(a,b) exige deux entiers sûrs');
    if (nativeAvailable()) { const v = window.NovaNative.gcd(String(a), String(b)); if (v !== 'ERREUR') return Number(v); }
    a = Math.abs(a); b = Math.abs(b);
    while (b) { const r = a % b; a = b; b = r; }
    return a;
  }
  function lcm(a, b) {
    if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b)) throw new Error('ppcm(a,b) exige deux entiers sûrs');
    if (nativeAvailable()) { const v = window.NovaNative.lcm(String(a), String(b)); if (v !== 'ERREUR') return Number(v); }
    if (!a || !b) return 0;
    const v = Math.abs((a / gcd(a, b)) * b);
    if (!Number.isSafeInteger(v)) throw new Error('PPCM trop grand');
    return v;
  }
  function hypot(a, b) {
    if (nativeAvailable()) { const v = window.NovaNative.hypot(String(a), String(b)); if (v !== 'ERREUR' && Number.isFinite(Number(v))) return Number(v); }
    return Math.hypot(a, b);
  }
  function combination(n, r, permutation) {
    if (!Number.isInteger(n) || !Number.isInteger(r) || n < 0 || r < 0 || r > n) throw new Error('nCr/nPr : vérifier n et r');
    r = permutation ? r : Math.min(r, n - r);
    let v = 1;
    for (let i = 0; i < r; i++) v *= n - i;
    if (!permutation) for (let i = 2; i <= r; i++) v /= i;
    if (!Number.isFinite(v)) throw new Error('Résultat trop grand');
    return v;
  }

  const toRadians = (x) => angleMode === 'DEG' ? x * Math.PI / 180 : x;
  const fromRadians = (x) => angleMode === 'DEG' ? x * 180 / Math.PI : x;
  function callFunction(name, args) {
    const x = args[0], y = args[1];
    switch (name) {
      case 'sin': return Math.sin(toRadians(x));
      case 'cos': return Math.cos(toRadians(x));
      case 'tan': return Math.tan(toRadians(x));
      case 'asin': return fromRadians(Math.asin(x));
      case 'acos': return fromRadians(Math.acos(x));
      case 'atan': return fromRadians(Math.atan(x));
      case 'atan2': return fromRadians(Math.atan2(x, y));
      case 'sinh': return Math.sinh(x); case 'cosh': return Math.cosh(x); case 'tanh': return Math.tanh(x);
      case 'asinh': return Math.asinh(x); case 'acosh': return Math.acosh(x); case 'atanh': return Math.atanh(x);
      case 'ln': return Math.log(x); case 'log': return Math.log10(x); case 'log2': return Math.log2(x);
      case 'sqrt': return Math.sqrt(x); case 'cbrt': return Math.cbrt(x); case 'abs': return Math.abs(x);
      case 'exp': return Math.exp(x); case 'floor': return Math.floor(x); case 'ceil': return Math.ceil(x);
      case 'round': return Math.round(x); case 'trunc': return Math.trunc(x); case 'sign': return Math.sign(x);
      case 'factorial': case 'fact': return factorial(x); case 'prime': case 'isprime': return prime(x);
      case 'gcd': case 'pgcd': return gcd(x, y); case 'lcm': case 'ppcm': return lcm(x, y);
      case 'hypot': return hypot(x, y); case 'ncr': return combination(x, y, false); case 'npr': return combination(x, y, true);
      case 'min': return Math.min(...args); case 'max': return Math.max(...args); case 'pow': return Math.pow(x, y);
      case 'root': return Math.pow(y, 1 / x); case 'mod': return x % y; case 'deg': return x * 180 / Math.PI; case 'rad': return x * Math.PI / 180;
      default: throw new Error(`Fonction inconnue : ${name}`);
    }
  }

  function parse(input) {
    const tokens = tokenize(input);
    if (!tokens.length) throw new Error('Saisis une expression');
    let pos = 0;
    const peek = () => tokens[pos];
    const take = () => tokens[pos++];
    const expect = (type, value) => {
      const t = take();
      if (!t || t.type !== type || (value !== undefined && t.value !== value)) throw new Error('Parenthèses ou arguments incomplets');
      return t;
    };
    const constants = { pi: Math.PI, e: Math.E, ans: answer, phi: (1 + Math.sqrt(5)) / 2 };
    const prec = (op) => op === '+' || op === '-' ? 1 : op === '*' || op === '/' ? 2 : op === '^' ? 4 : -1;

    function prefix() {
      const t = take();
      if (!t) throw new Error('Expression incomplète');
      if (t.type === 'number') return t.value;
      if (t.type === 'op' && (t.value === '+' || t.value === '-')) {
        const v = expr(3);
        return t.value === '-' ? -v : v;
      }
      if (t.type === '(') { const v = expr(0); expect(')'); return v; }
      if (t.type === 'ident') {
        if (peek() && peek().type === '(') {
          take();
          const args = [];
          if (!peek() || peek().type !== ')') {
            while (true) {
              args.push(expr(0));
              if (peek() && peek().type === ',') { take(); continue; }
              break;
            }
          }
          expect(')');
          return callFunction(t.value, args);
        }
        if (Object.prototype.hasOwnProperty.call(constants, t.value)) return constants[t.value];
        throw new Error(`Nom inconnu : ${t.value}`);
      }
      throw new Error('Expression invalide');
    }
    function expr(minPrec) {
      let left = prefix();
      while (peek()) {
        const t = peek();
        if (t.type === 'op' && (t.value === '!' || t.value === '%')) {
          take(); left = t.value === '!' ? factorial(left) : left / 100; continue;
        }
        if (t.type !== 'op') break;
        const p = prec(t.value);
        if (p < minPrec) break;
        take();
        const right = expr(t.value === '^' ? p : p + 1);
        if (t.value === '+') left += right;
        else if (t.value === '-') left -= right;
        else if (t.value === '*') left *= right;
        else if (t.value === '/') { if (right === 0) throw new Error('Division par zéro'); left /= right; }
        else if (t.value === '^') left = Math.pow(left, right);
      }
      return left;
    }
    const value = expr(0);
    if (pos !== tokens.length) throw new Error('Expression non terminée');
    if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error('Résultat indéfini dans les nombres réels');
    return value;
  }


const tests=[['2+3*4',14],['sin(30)',0.5],['sqrt(16)+2^3',12],['5!',120],['nCr(10,3)',120],['gcd(48,18)',6],['lcm(12,18)',36],['hypot(3,4)',5],['-2^2',-4],['2π',2*Math.PI],['2(3+4)',14],['log(1000)',3],['asin(0.5)',30],['10%',0.1],['1e3+2',1002]];
let ok=true; for (const [x,e] of tests) { const a=parse(x); const pass=Math.abs(a-e)<1e-9; console.log((pass?'PASS':'FAIL')+' '+x+' -> '+a+' expected '+e); if(!pass)ok=false; } if(!ok)process.exit(1);