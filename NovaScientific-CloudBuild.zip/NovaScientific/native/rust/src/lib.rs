use std::ffi::c_void;

fn gcd_u64(mut a: u64, mut b: u64) -> u64 {
    while b != 0 {
        let r = a % b;
        a = b;
        b = r;
    }
    a
}

#[no_mangle]
pub extern "system" fn Java_com_moonboy_scicalc_NativeMath_rustGcd(
    _env: *mut c_void, _this: *mut c_void, a: i64, b: i64,
) -> i64 {
    let g = gcd_u64(a.unsigned_abs(), b.unsigned_abs());
    if g > i64::MAX as u64 { -1 } else { g as i64 }
}

#[no_mangle]
pub extern "system" fn Java_com_moonboy_scicalc_NativeMath_rustLcm(
    _env: *mut c_void, _this: *mut c_void, a: i64, b: i64,
) -> i64 {
    if a == 0 || b == 0 { return 0; }
    let g = gcd_u64(a.unsigned_abs(), b.unsigned_abs());
    let v = (a.unsigned_abs() as u128 / g as u128) * b.unsigned_abs() as u128;
    if v > i64::MAX as u128 { -1 } else { v as i64 }
}

#[no_mangle]
pub extern "system" fn Java_com_moonboy_scicalc_NativeMath_rustHypot(
    _env: *mut c_void, _this: *mut c_void, a: f64, b: f64,
) -> f64 {
    a.hypot(b)
}

fn mod_pow(base: i64, exponent: i64, modulus: i64) -> Option<i64> {
    if exponent < 0 || modulus <= 0 { return None; }
    let m = modulus as u128;
    let mut factor = (base as i128).rem_euclid(modulus as i128) as u128;
    let mut result = 1_u128 % m;
    let mut power = exponent as u64;
    while power > 0 {
        if power & 1 != 0 { result = (result * factor) % m; }
        factor = (factor * factor) % m;
        power >>= 1;
    }
    Some(result as i64)
}

#[no_mangle]
pub extern "system" fn Java_com_moonboy_scicalc_NativeMath_rustModPow(
    _env: *mut c_void, _this: *mut c_void, base: i64, exponent: i64, modulus: i64,
) -> i64 {
    mod_pow(base, exponent, modulus).unwrap_or(-1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn modular_powers_handle_signed_values_and_boundaries() {
        assert_eq!(mod_pow(2, 10, 1000), Some(24));
        assert_eq!(mod_pow(-2, 3, 5), Some(2));
        assert_eq!(mod_pow(0, 0, 1), Some(0));
        assert_eq!(mod_pow(7, 0, 13), Some(1));
        assert_eq!(mod_pow(i64::MIN, 1, i64::MAX), Some(i64::MAX - 1));
        assert_eq!(mod_pow(i64::MAX - 1, 2, i64::MAX), Some(1));
        assert_eq!(mod_pow(2, -1, 3), None);
        assert_eq!(mod_pow(2, 1, 0), None);
        assert_eq!(mod_pow(2, 1, -3), None);
    }

    #[test]
    fn gcd_handles_zero_and_unsigned_extremes() {
        assert_eq!(gcd_u64(0, 0), 0);
        assert_eq!(gcd_u64(48, 18), 6);
        assert_eq!(gcd_u64(1 << 63, 1 << 62), 1 << 62);
    }
}
