use std::ffi::c_void;

fn gcd_u64(mut a: u64, mut b: u64) -> u64 {
    while b != 0 {
        let r = a % b;
        a = b;
        b = r;
    }
    a
}

#[no_mangle]
pub extern "system" fn Java_com_moonboy_scicalc_NativeMath_rustGcd(
    _env: *mut c_void, _this: *mut c_void, a: i64, b: i64,
) -> i64 {
    let g = gcd_u64(a.unsigned_abs(), b.unsigned_abs());
    if g > i64::MAX as u64 { -1 } else { g as i64 }
}

#[no_mangle]
pub extern "system" fn Java_com_moonboy_scicalc_NativeMath_rustLcm(
    _env: *mut c_void, _this: *mut c_void, a: i64, b: i64,
) -> i64 {
    if a == 0 || b == 0 { return 0; }
    let g = gcd_u64(a.unsigned_abs(), b.unsigned_abs());
    let v = (a.unsigned_abs() as u128 / g as u128) * b.unsigned_abs() as u128;
    if v > i64::MAX as u128 { -1 } else { v as i64 }
}

#[no_mangle]
pub extern "system" fn Java_com_moonboy_scicalc_NativeMath_rustHypot(
    _env: *mut c_void, _this: *mut c_void, a: f64, b: f64,
) -> f64 {
    a.hypot(b)
}
