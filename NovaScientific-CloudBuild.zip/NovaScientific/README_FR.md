# Nova Scientific — calculatrice scientifique Android

Nova Scientific est un projet Android hors ligne, pensé pour une interface de calculatrice scientifique physique. Il rassemble réellement les quatre technologies demandées dans **une même application et une même APK** :

- **Kotlin** : activité Android, WebView et pont JNI sécurisé par des méthodes explicites.
- **JavaScript** : analyseur d'expressions arithmétiques et scientifiques, interface, historique, matrices et nombres complexes.
- **C/C++** : factorielle entière (jusqu'à 20!) et test de primalité exposés par JNI.
- **Rust** : PGCD, PPCM avec détection du dépassement et hypoténuse, exposés par JNI.

L'application n'utilise aucune connexion Internet et ne demande aucune permission Android. La version actuelle produit une APK **arm64-v8a**, adaptée aux téléphones Android ARM 64 bits récents.

## Fonctions actuelles

Trigonométrie en degrés/radians, fonctions trigonométriques inverses, fonctions hyperboliques, logarithmes, puissances, racines carrées/cubiques, factorielle, pourcentage, constantes π/e/φ, Ans, mémoire M+/M−/MR/MC, PGCD/PPCM, primalité, nCr/nPr, hypoténuse, historique de session, déterminants 2×2 et 3×3, module et argument d'un nombre complexe.

Le moteur d'expressions utilise un analyseur dédié, pas `eval()` ni du code JavaScript arbitraire. La factorielle et les fonctions arithmétiques natives disposent d'un chemin de secours JavaScript pour permettre un aperçu dans un navigateur.

## Compiler sur Windows (PC HP)

### 1. Installer les outils une seule fois

1. Installe **Android Studio** et son JDK intégré.
2. Dans Android Studio → **SDK Manager**, installe Android SDK Platform 35, Android SDK Build-Tools, **NDK (Side by side) 27.0.12077973** et **CMake 3.22.1**.
3. Installe Rust avec rustup. Après avoir ouvert un nouveau terminal Windows, exécute :

   ```powershell
   rustup target add aarch64-linux-android
   cargo install cargo-ndk
   ```

4. Ouvre le projet `NovaScientific` dans Android Studio pour que l'IDE configure le chemin du SDK. Le PC doit avoir accès à Internet lors du premier build pour récupérer Gradle et les plugins Android.

### 2. Générer l'APK

Depuis le dossier du projet, double-clique sur `build.bat`, ou lance dans un terminal :

```powershell
.\gradlew.bat assembleDebug
```

Le script utilise Gradle 8.9 (téléchargé dans le dossier utilisateur s'il manque), puis la tâche Gradle compile la bibliothèque Rust avant la compilation Android/C++.

L'APK de débogage est générée ici :

`app\build\outputs\apk\debug\app-debug.apk`

Transfère ce fichier vers le téléphone et installe-le. Une APK debug est signée automatiquement avec la clé de débogage locale. Pour publier, crée une clé de signature personnelle et utilise une configuration `release`.

## Vérifications rapides

Dans l'application, teste par exemple :

- `sin(30)` en mode DEG → `0.5`
- `sqrt(16)+2^3` → `12`
- `5!` → `120`
- `nCr(10,3)` → `120`
- `gcd(48,18)` → `6`
- `hypot(3,4)` → `5`

Les outils matrices et nombres complexes sont accessibles via l'icône en haut à droite.

## Limites connues de la version 1.0

- Le binaire Rust est construit pour **arm64-v8a uniquement**. Pour émulateur x86_64 ou appareils Android ARM 32 bits, il faut ajouter les cibles Rust correspondantes et les ABI au Gradle.
- La mémoire et l'historique sont conservés uniquement pendant la session de l'application.
- Le résultat est calculé en nombres flottants `Double`, et non en calcul symbolique exact ou en CAS. Les calculs très grands peuvent donc perdre de la précision.
- Le code source a été créé ici, mais aucune APK compilée n'est incluse : cet environnement ne dispose pas du SDK Android, de Gradle ni de Rust. La compilation doit être faite sur un poste équipé des outils indiqués ci-dessus.

## Compiler dans le cloud avec GitHub Actions (sans PC)

Le dépôt inclut le workflow `.github/workflows/android-apk.yml`. Après avoir importé ce dossier dans un dépôt GitHub :

1. Ouvre l'onglet **Actions** du dépôt.
2. Sélectionne **Build Nova Scientific APK**.
3. Appuie sur **Run workflow** puis confirme.
4. Attends la fin du job. Si le build réussit, ouvre l'exécution et télécharge l'artefact **NovaScientific-debug-apk**.
5. Extrais le ZIP de l'artefact : il contient `app-debug.apk`.

Le workflow installe Java 17, Android SDK 35, NDK 27, CMake 3.22.1, Rust et `cargo-ndk`, puis exécute `assembleDebug`. Il ne demande aucun secret GitHub : l'APK est publiée comme artefact temporaire pendant 14 jours.

**À savoir :** le workflow est préparé mais n'a pas encore été exécuté sur GitHub. Le premier lancement servira à révéler d'éventuelles erreurs de compilation ou de dépendances. Aucune APK n'est générée tant que l'exécution GitHub Actions n'a pas terminé avec succès.
