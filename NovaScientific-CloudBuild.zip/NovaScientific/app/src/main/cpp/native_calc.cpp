#include <jni.h>
#include <cstdint>
#include <cmath>

extern "C" JNIEXPORT jlong JNICALL
Java_com_moonboy_scicalc_NativeMath_cFactorial(JNIEnv *, jobject, jlong n) {
    // Résultat entier exact limité à 20!, qui tient dans un entier signé 64 bits.
    if (n < 0 || n > 20) return static_cast<jlong>(-1);
    jlong result = 1;
    for (jlong i = 2; i <= n; ++i) result *= i;
    return result;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_moonboy_scicalc_NativeMath_cIsPrime(JNIEnv *, jobject, jlong n) {
    if (n < 2) return JNI_FALSE;
    if (n == 2) return JNI_TRUE;
    if ((n % 2) == 0) return JNI_FALSE;
    for (jlong i = 3; i <= n / i; i += 2) {
        if ((n % i) == 0) return JNI_FALSE;
    }
    return JNI_TRUE;
}

#include "integer_math.h"
extern "C" JNIEXPORT jlong JNICALL
Java_com_moonboy_scicalc_NativeMath_cIntegerSqrt(JNIEnv *, jobject, jlong value) {
    return static_cast<jlong>(nova::integer_sqrt(static_cast<std::int64_t>(value)));
}
