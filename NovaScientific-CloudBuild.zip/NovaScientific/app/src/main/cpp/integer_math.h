#pragma once
#include <cstdint>

namespace nova {
// Integer square root using binary search and division to avoid overflow.
inline std::int64_t integer_sqrt(std::int64_t value) {
    if (value < 0) return -1;
    std::int64_t lo = 0;
    std::int64_t hi = value < 3037000499LL ? value : 3037000499LL;
    while (lo < hi) {
        const std::int64_t mid = lo + (hi - lo + 1) / 2;
        if (mid <= value / mid) lo = mid;
        else hi = mid - 1;
    }
    return lo;
}
}
