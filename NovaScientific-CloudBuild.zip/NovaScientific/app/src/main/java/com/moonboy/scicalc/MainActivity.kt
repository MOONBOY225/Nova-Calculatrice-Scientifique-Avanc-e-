package com.moonboy.scicalc

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val nativeMath by lazy { NativeMath() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(12, 16, 29)
        window.navigationBarColor = android.graphics.Color.rgb(12, 16, 29)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(12, 16, 29))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.javaScriptCanOpenWindowsAutomatically = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(NativeBridge(), "NovaNative")
        }
        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (webView.url?.endsWith("index.html") == true && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun factorial(value: String): String = try {
            val n = value.toLong()
            val result = nativeMath.cFactorial(n)
            if (result < 0) "ERREUR" else result.toString()
        } catch (_: Throwable) { "ERREUR" }

        @JavascriptInterface
        fun isPrime(value: String): String = try {
            val n = value.toLong()
            if (nativeMath.cIsPrime(n)) "1" else "0"
        } catch (_: Throwable) { "ERREUR" }

        @JavascriptInterface
        fun gcd(a: String, b: String): String = try {
            nativeMath.rustGcd(a.toLong(), b.toLong()).let { if (it < 0) "ERREUR" else it.toString() }
        } catch (_: Throwable) { "ERREUR" }

        @JavascriptInterface
        fun lcm(a: String, b: String): String = try {
            nativeMath.rustLcm(a.toLong(), b.toLong()).let { if (it < 0) "ERREUR" else it.toString() }
        } catch (_: Throwable) { "ERREUR" }

        @JavascriptInterface
        fun hypot(a: String, b: String): String = try {
            val result = nativeMath.rustHypot(a.toDouble(), b.toDouble())
            if (result.isFinite()) String.format(Locale.US, "%.12g", result) else "ERREUR"
        } catch (_: Throwable) { "ERREUR" }

        @JavascriptInterface
        fun engineStatus(): String = "Kotlin + C/C++ + Rust + JavaScript"
    }
}
