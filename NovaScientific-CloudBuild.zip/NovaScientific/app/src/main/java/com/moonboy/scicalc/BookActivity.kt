package com.moonboy.scicalc

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.min

/** Lecteur PDF hors ligne : une seule page est chargée à la fois, hors du thread UI. */
class BookActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var image: ImageView
    private lateinit var position: TextView
    private lateinit var pageInput: EditText
    private lateinit var previous: Button
    private lateinit var next: Button
    private lateinit var go: Button
    private var page = 0
    private var pageCount = 0
    private var closed = false
    private lateinit var assetName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assetName = when (intent.getStringExtra("book")) {
            "guide" -> "guide-accompagnateur.pdf"
            else -> "la-voie-du-nombre.pdf"
        }
        page = savedInstanceState?.getInt("page") ?: 0
        window.statusBarColor = Color.rgb(12, 16, 29)
        window.navigationBarColor = Color.rgb(12, 16, 29)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(12, 16, 29))
            setPadding(16, 12, 16, 12)
        }
        val title = TextView(this).apply {
            text = if (assetName.startsWith("guide")) "Guide de l’accompagnateur" else "La Voie du Nombre"
            textSize = 19f; setTextColor(Color.WHITE); setPadding(4, 8, 4, 8)
        }
        position = TextView(this).apply { textSize = 14f; setTextColor(Color.rgb(194, 211, 227)); setPadding(4, 4, 4, 8) }
        image = ImageView(this).apply { adjustViewBounds = true; contentDescription = "Page du manuel de mathématiques" }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(image) }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        previous = Button(this).apply { text = "‹"; contentDescription = "Page précédente"; setOnClickListener { render(page - 1) } }
        next = Button(this).apply { text = "›"; contentDescription = "Page suivante"; setOnClickListener { render(page + 1) } }
        pageInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Page"; contentDescription = "Numéro de page"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        go = Button(this).apply { text = "Aller"; setOnClickListener {
            val n = pageInput.text.toString().toIntOrNull()
            if (n == null || n !in 1..pageCount) Toast.makeText(this@BookActivity, "Choisis une page entre 1 et $pageCount", Toast.LENGTH_SHORT).show()
            else render(n - 1)
        } }
        controls.addView(previous)
        controls.addView(pageInput, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(go); controls.addView(next)
        column.addView(title); column.addView(position)
        column.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        column.addView(controls)
        setContentView(column)
        render(page)
    }

    private fun render(requestedPage: Int) {
        previous.isEnabled = false; next.isEnabled = false; go.isEnabled = false
        position.text = "Chargement de la page…"
        val screenWidth = resources.displayMetrics.widthPixels
        worker.execute {
            try {
                val file = File(cacheDir, assetName)
                val size = assets.openFd("books/$assetName").use { it.length }
                synchronized(BookActivity::class.java) {
                    if (!file.exists() || file.length() != size) {
                        val partial = File(cacheDir, "$assetName.part")
                        try {
                            assets.open("books/$assetName").use { input -> partial.outputStream().use { input.copyTo(it) } }
                            if (!partial.renameTo(file)) throw IllegalStateException("Copie du manuel impossible")
                        } finally { if (partial.exists()) partial.delete() }
                    }
                }
                val rendered = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                    PdfRenderer(fd).use { pdf ->
                        val count = pdf.pageCount
                        require(count > 0) { "Le manuel ne contient aucune page" }
                        val index = requestedPage.coerceIn(0, count - 1)
                        pdf.openPage(index).use { pdfPage ->
                            val desiredWidth = min((screenWidth * 2).coerceAtLeast(600), 1800)
                            val scale = min(desiredWidth.toDouble() / pdfPage.width, 2600.0 / pdfPage.height)
                            val width = (pdfPage.width * scale).toInt().coerceAtLeast(1)
                            val height = (pdfPage.height * scale).toInt().coerceAtLeast(1)
                            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            bitmap.eraseColor(Color.WHITE)
                            pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            Triple(count, index, bitmap)
                        }
                    }
                }
                val (count, index, bitmap) = rendered
                runOnUiThread {
                    if (closed) { bitmap.recycle(); return@runOnUiThread }
                    pageCount = count; page = index; image.setImageBitmap(bitmap)
                    image.contentDescription = "Page ${page + 1} sur $pageCount du manuel"
                    position.text = "Page ${page + 1} / $pageCount · lecture hors ligne"
                    pageInput.setText((page + 1).toString())
                    previous.isEnabled = page > 0; next.isEnabled = page + 1 < pageCount; go.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { if (!closed) position.text = "Impossible d’ouvrir le manuel. Vérifie l’espace disponible et réessaie." }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) { outState.putInt("page", page); super.onSaveInstanceState(outState) }
    override fun onDestroy() { closed = true; worker.shutdown(); super.onDestroy() }
}
