package com.moonboy.scicalc

/** Pont JNI vers les deux moteurs natifs : C/C++ et Rust. */
class NativeMath {
    companion object {
        init {
            System.loadLibrary("native_calc")
            System.loadLibrary("rust_calc")
        }
    }

    external fun cFactorial(n: Long): Long
    external fun cIntegerSqrt(n: Long): Long
    external fun cIsPrime(n: Long): Boolean
    external fun rustGcd(a: Long, b: Long): Long
    external fun rustLcm(a: Long, b: Long): Long
    external fun rustModPow(base: Long, exponent: Long, modulus: Long): Long
    external fun rustHypot(a: Double, b: Double): Double
}
