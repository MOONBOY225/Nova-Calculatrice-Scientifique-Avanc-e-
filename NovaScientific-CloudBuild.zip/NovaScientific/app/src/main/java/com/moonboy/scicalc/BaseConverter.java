package com.moonboy.scicalc;

import java.math.BigInteger;
import java.util.Locale;

/** Exact conversion of signed integers in commonly used bases. */
public final class BaseConverter {
    private static final int MAX_DIGITS = 256;

    private BaseConverter() {}

    public static String convert(String input, int fromBase, int toBase) {
        if (!supported(fromBase) || !supported(toBase) || input == null) {
            throw new IllegalArgumentException("Base non prise en charge");
        }
        String value = input.trim();
        if (value.isEmpty()) throw new IllegalArgumentException("Saisis un entier");
        boolean negative = value.charAt(0) == '-';
        String digits = negative ? value.substring(1) : value;
        if (digits.isEmpty() || digits.length() > MAX_DIGITS) {
            throw new IllegalArgumentException("Saisis entre 1 et 256 chiffres");
        }
        for (int i = 0; i < digits.length(); i++) {
            char c = digits.charAt(i);
            int digit = c >= '0' && c <= '9' ? c - '0' :
                c >= 'A' && c <= 'F' ? c - 'A' + 10 :
                c >= 'a' && c <= 'f' ? c - 'a' + 10 : -1;
            if (digit < 0 || digit >= fromBase) {
                throw new IllegalArgumentException("Chiffre invalide pour cette base");
            }
        }
        return new BigInteger(value, fromBase).toString(toBase).toUpperCase(Locale.ROOT);
    }

    private static boolean supported(int base) {
        return base == 2 || base == 8 || base == 10 || base == 16;
    }
}
