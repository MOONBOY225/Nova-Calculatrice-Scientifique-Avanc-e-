# Les symboles JNI sont exportés explicitement par nom.
-keep class com.moonboy.scicalc.NativeMath { *; }
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
