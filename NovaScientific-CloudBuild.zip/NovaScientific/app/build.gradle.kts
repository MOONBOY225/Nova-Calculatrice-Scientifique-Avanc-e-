import org.gradle.api.tasks.Exec
import org.gradle.api.tasks.Copy

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val rustManifest = layout.projectDirectory.file("../native/rust/Cargo.toml")
val rustOutput = layout.projectDirectory.dir("src/main/jniLibs")

val buildRustNative by tasks.registering(Exec::class) {
    group = "build"
    description = "Compile le moteur Rust pour Android arm64-v8a (cargo-ndk requis)."
    workingDir(rustManifest.asFile.parentFile)
    commandLine(
        "cargo", "ndk", "-t", "arm64-v8a", "--platform", "23",
        "-o", rustOutput.asFile.absolutePath,
        "build", "--manifest-path", rustManifest.asFile.absolutePath, "--release"
    )
    inputs.file(rustManifest)
    inputs.dir(layout.projectDirectory.dir("../native/rust/src"))
    outputs.file(rustOutput.file("arm64-v8a/librust_calc.so"))
}

tasks.named("preBuild").configure { dependsOn(buildRustNative) }

android {
    namespace = "com.moonboy.scicalc"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.moonboy.scicalc"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "1.4.0"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake { cppFlags += listOf("-std=c++17", "-O2") }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" }
    }

    androidResources { noCompress += "pdf" }
    packaging { jniLibs { useLegacyPackaging = false } }
}
