import com.moonboy.scicalc.BaseConverter;
import java.math.BigInteger;
import java.util.Random;

public class BaseConverterTest {
    private static void eq(String actual, String expected) {
        if (!actual.equals(expected)) throw new AssertionError(actual + " != " + expected);
    }
    private static void rejects(String value, int from, int to) {
        try { BaseConverter.convert(value, from, to); throw new AssertionError("Expected error: " + value); }
        catch (IllegalArgumentException expected) { }
    }
    public static void main(String[] args) {
        eq(BaseConverter.convert("255", 10, 16), "FF");
        eq(BaseConverter.convert("-ff", 16, 2), "-11111111");
        eq(BaseConverter.convert("-0", 10, 8), "0");
        eq(BaseConverter.convert("  0010  ", 2, 10), "2");
        rejects("", 10, 2); rejects("-", 10, 2); rejects("2", 2, 10);
        rejects("1_0", 10, 2); rejects("+1", 10, 2); rejects("1", 3, 10);
        rejects("1", 10, 17); rejects("9".repeat(257), 10, 2);
        int[] bases = {2, 8, 10, 16};
        Random random = new Random(287);
        for (int i = 0; i < 1000; i++) {
            BigInteger value = new BigInteger(250, random);
            if ((i & 1) == 1) value = value.negate();
            for (int from : bases) for (int to : bases) {
                String input = value.toString(from);
                eq(BaseConverter.convert(input, from, to), value.toString(to).toUpperCase(java.util.Locale.ROOT));
            }
        }
        System.out.println("PASS: Java base conversion and 16000 round-trip cases");
    }
}
