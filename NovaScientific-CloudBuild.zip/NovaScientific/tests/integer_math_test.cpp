#include "../app/src/main/cpp/integer_math.h"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <limits>
int main() {
    using nova::integer_sqrt;
    assert(integer_sqrt(-1) == -1);
    assert(integer_sqrt(0) == 0);
    assert(integer_sqrt(1) == 1);
    assert(integer_sqrt(2) == 1);
    assert(integer_sqrt(81) == 9);
    assert(integer_sqrt(99) == 9);
    assert(integer_sqrt(std::numeric_limits<std::int64_t>::max()) == 3037000499LL);
    for (std::int64_t i = 1; i < 100000; ++i) {
        assert(integer_sqrt(i * i) == i);
        assert(integer_sqrt(i * i - 1) == i - 1);
        assert(integer_sqrt(i * i + i) == i);
    }
    std::cout << "PASS: C++ integer square root boundaries and 299997 cases\n";
}
