// Integration tests exercise the shipped UI and parser, not a duplicate parser.
const { JSDOM } = require('jsdom');
const fs = require('fs');
const assert = require('assert');
const path = require('path');
const assets = path.join(__dirname, 'app/src/main/assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(assets, 'calculator.js'), 'utf8');
let persisted = null;
function createApp() {
  const dom = new JSDOM(html, { url: 'https://nova.local/', runScripts: 'outside-only' });
  if (persisted !== null) dom.window.localStorage.setItem('nova-scientific-v1', persisted);
  dom.window.confirm = () => true;
  dom.window.eval(js.replace('  restoreState();', '  window.__parseForTest = parse;\n  restoreState();')); 
  return dom;
}
let dom = createApp(), d = dom.window.document;
function press(selector) { const el = d.querySelector(selector); assert(el, selector); el.click(); }
function key(k) { d.dispatchEvent(new dom.window.KeyboardEvent('keydown', {key:k, bubbles:true})); }
function clear() { press('[data-action="clear"]'); }
function calculate(expression) { clear(); for (const c of expression) key(c); key('Enter'); return d.getElementById('result').textContent; }
assert.equal(calculate('2+3*4'), '14');
assert.equal(calculate('1/1000000000000000'), '1e-15');
const parse = expression => dom.window.__parseForTest(expression);
assert.equal(parse('nCr(100,3)'), 161700);
assert.equal(parse('root(-8,3)'), -2);
assert.equal(parse('min(3,2,1)'), 1);
assert.throws(() => parse('root(2,0)'), /zéro/);
assert.throws(() => parse('sin(1,2)'), /arguments/);
assert.throws(() => parse('min()'), /arguments/);
assert.throws(() => parse('prime(1000000000001)'), /trop grand/);
assert.throws(() => parse('1'.repeat(513)), /trop longue/);
assert.equal(calculate('2/0'), 'Erreur');
assert.match(d.getElementById('statusMessage').textContent, /Division par zéro/);

clear(); press('[data-normal="sin"]'); press('[data-insert="3"]'); press('[data-insert="0"]'); key(')'); press('[data-action="evaluate"]');
assert(Math.abs(Number(d.getElementById('result').textContent) - 0.5) < 1e-12);
clear(); press('[data-insert="8"]'); press('[data-action="shift"]'); press('[data-normal="xʸ"]'); press('[data-insert="3"]'); key(')'); press('[data-action="evaluate"]');
assert.equal(d.getElementById('result').textContent, '2');
press('[data-angle="RAD"]');
d.getElementById('openSettings').focus(); press('#openSettings'); assert(!d.getElementById('modalBackdrop').classList.contains('hidden'));
d.getElementById('accentSetting').value = 'blue'; d.getElementById('accentSetting').dispatchEvent(new dom.window.Event('change', { bubbles:true }));
d.getElementById('soundSetting').checked = true; d.getElementById('soundSetting').dispatchEvent(new dom.window.Event('change', { bubbles:true }));
key('Escape'); assert(d.getElementById('modalBackdrop').classList.contains('hidden'));
assert.equal(d.activeElement.id, 'openSettings');
persisted = dom.window.localStorage.getItem('nova-scientific-v1'); dom.window.close();
dom = createApp(); d = dom.window.document;
assert.equal(d.documentElement.dataset.accent, 'blue');
assert.equal(d.getElementById('angleChip').textContent, 'RAD');
press('#openHistory'); assert(d.querySelectorAll('.history-item').length >= 3); press('#closeModal');
press('#openSettings'); assert(d.getElementById('soundSetting').checked); press('#closeModal');
press('#clearHistory'); press('#openHistory'); assert(d.querySelector('.empty-state')); press('#closeModal');
press('#openTools'); press('[data-tool="convert"]');
press('#convertCompute'); assert.match(d.getElementById('convertResult').textContent, /0.001 km/);
d.getElementById('convertCategory').value = 'temperature'; d.getElementById('convertCategory').dispatchEvent(new dom.window.Event('change', { bubbles:true }));
d.getElementById('convertValue').value = '100'; press('#convertCompute'); assert.match(d.getElementById('convertResult').textContent, /212 f/);
d.getElementById('convertValue').value = '-300'; press('#convertCompute'); assert.match(d.getElementById('convertResult').textContent, /zéro absolu/);
d.getElementById('convertValue').value = ''; press('#convertCompute'); assert.match(d.getElementById('convertResult').textContent, /valeur numérique/);
press('#closeModal');
press('#openTools'); press('[data-tool="matrix"]'); d.getElementById('m0').value = ''; press('#matrixCompute'); assert.match(d.getElementById('matrixResult').textContent, /invalide/); press('#closeModal');
press('#openTools'); press('[data-tool="complex"]'); d.getElementById('complexReal').value = '0'; d.getElementById('complexImag').value = '0'; press('#complexCompute'); assert.match(d.getElementById('complexResult').textContent, /indéfini/); press('#closeModal');

// Test real tool handlers with normal, invalid and degenerate inputs.
press('#openTools'); press('[data-tool="stats"]');
d.getElementById('statsValues').value = '2; 4; 4; 8'; press('#statsCompute');
assert.match(d.getElementById('statsResult').textContent, /moyenne = 4.5/);
assert.match(d.getElementById('statsResult').textContent, /médiane = 4/);
d.getElementById('statsValues').value = '1; mauvais'; press('#statsCompute'); assert.match(d.getElementById('statsResult').textContent, /nombres valides/); press('#closeModal');
press('#openTools'); press('[data-tool="equation"]'); press('#eqCompute');
assert.match(d.getElementById('eqResult').textContent, /x₁ = 2 · x₂ = 1/);
d.getElementById('eqA').value = '0'; d.getElementById('eqB').value = '2'; d.getElementById('eqC').value = '-4'; press('#eqCompute'); assert.match(d.getElementById('eqResult').textContent, /x = 2/);
d.getElementById('eqA').value = '1'; d.getElementById('eqB').value = '0'; d.getElementById('eqC').value = '1'; press('#eqCompute'); assert.match(d.getElementById('eqResult').textContent, /± 1 i/); press('#closeModal');
let opened = '';
dom.window.NovaNative = { openBook: which => { opened = which; } };
press('#openTools'); press('[data-tool="library"]'); press('#openCourse'); assert.equal(opened, 'course'); press('#openGuide'); assert.equal(opened, 'guide'); press('#closeModal');
delete dom.window.NovaNative;
for (const name of ['la-voie-du-nombre.pdf', 'guide-accompagnateur.pdf', 'LICENSE.txt']) assert(fs.statSync(path.join(assets, 'books', name)).size > 100);
// A focused button must retain native Enter behavior without a second calculation.
const before = JSON.parse(dom.window.localStorage.getItem('nova-scientific-v1')).history.length;
d.querySelector('[data-action="clear"]').focus();
d.querySelector('[data-action="clear"]').dispatchEvent(new dom.window.KeyboardEvent('keydown', {key:'Enter', bubbles:true}));
assert.equal(JSON.parse(dom.window.localStorage.getItem('nova-scientific-v1')).history.length, before);
console.log('PASS: calculs, erreurs, conversions, équations, statistiques, bibliothèque et historique');
dom.window.close();
