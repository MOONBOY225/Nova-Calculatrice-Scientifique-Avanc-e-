// Integration tests exercise the shipped UI and parser, not a duplicate parser.
const { JSDOM } = require('jsdom');
const fs = require('fs');
const assert = require('assert');
const path = require('path');
const assets = path.join(__dirname, 'app/src/main/assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(assets, 'calculator.js'), 'utf8');
let persisted = null;
function createApp() {
  const dom = new JSDOM(html, { url: 'https://nova.local/', runScripts: 'outside-only' });
  if (persisted !== null) dom.window.localStorage.setItem('nova-scientific-v1', persisted);
  dom.window.confirm = () => true;
  dom.window.eval(js);
  return dom;
}
let dom = createApp(), d = dom.window.document;
function press(selector) { const el = d.querySelector(selector); assert(el, selector); el.click(); }
function key(k) { d.dispatchEvent(new dom.window.KeyboardEvent('keydown', {key:k, bubbles:true})); }
function clear() { press('[data-action="clear"]'); }
function calculate(expression) { clear(); for (const c of expression) key(c); key('Enter'); return d.getElementById('result').textContent; }
assert.equal(calculate('2+3*4'), '14');
assert.equal(calculate('1/1000000000000000'), '1e-15');
clear(); press('[data-normal="sin"]'); press('[data-insert="3"]'); press('[data-insert="0"]'); key(')'); press('[data-action="evaluate"]');
assert(Math.abs(Number(d.getElementById('result').textContent) - 0.5) < 1e-12);
clear(); press('[data-insert="8"]'); press('[data-action="shift"]'); press('[data-normal="xʸ"]'); press('[data-insert="3"]'); key(')'); press('[data-action="evaluate"]');
assert.equal(d.getElementById('result').textContent, '2');
press('[data-angle="RAD"]');
d.getElementById('openSettings').focus(); press('#openSettings'); assert(!d.getElementById('modalBackdrop').classList.contains('hidden'));
d.getElementById('accentSetting').value = 'blue'; d.getElementById('accentSetting').dispatchEvent(new dom.window.Event('change', { bubbles:true }));
d.getElementById('soundSetting').checked = true; d.getElementById('soundSetting').dispatchEvent(new dom.window.Event('change', { bubbles:true }));
key('Escape'); assert(d.getElementById('modalBackdrop').classList.contains('hidden'));
assert.equal(d.activeElement.id, 'openSettings');
persisted = dom.window.localStorage.getItem('nova-scientific-v1'); dom.window.close();
dom = createApp(); d = dom.window.document;
assert.equal(d.documentElement.dataset.accent, 'blue');
assert.equal(d.getElementById('angleChip').textContent, 'RAD');
press('#openHistory'); assert(d.querySelectorAll('.history-item').length >= 3); press('#closeModal');
press('#openSettings'); assert(d.getElementById('soundSetting').checked); press('#closeModal');
press('#clearHistory'); press('#openHistory'); assert(d.querySelector('.empty-state')); press('#closeModal');
// A focused button must retain native Enter behavior without a second calculation.
const before = JSON.parse(dom.window.localStorage.getItem('nova-scientific-v1')).history.length;
d.querySelector('[data-action="clear"]').focus();
d.querySelector('[data-action="clear"]').dispatchEvent(new dom.window.KeyboardEvent('keydown', {key:'Enter', bubbles:true}));
assert.equal(JSON.parse(dom.window.localStorage.getItem('nova-scientific-v1')).history.length, before);
console.log('PASS: calculs, racine, précision, réglages, historique, clavier et dialogue');
dom.window.close();
