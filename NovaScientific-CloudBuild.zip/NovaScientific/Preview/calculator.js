(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const expressionEl = $('expression');
  const resultEl = $('result');
  const statusEl = $('statusMessage');
  const angleChip = $('angleChip');
  const memoryIndicator = $('memoryIndicator');
  const modalBackdrop = $('modalBackdrop');
  const modalTitle = $('modalTitle');
  const modalBody = $('modalBody');

  let expression = '';
  let answer = 0;
  let memory = null;
  let angleMode = 'DEG';
  let shifted = false;
  let lastResult = 0;
  let history = [];
  let settings = { sound: false, accent: 'mint' };
  let returnFocus = null;
  let audioContext;
  const storageKey = 'nova-scientific-v1';
  function saveState() {
    try { localStorage.setItem(storageKey, JSON.stringify({ history, memory, answer, angleMode, settings })); } catch (_) { /* storage can be unavailable */ }
  }
  function restoreState() {
    try {
      const data = JSON.parse(localStorage.getItem(storageKey) || '{}');
      if (Array.isArray(data.history)) history = data.history.filter(h => h && typeof h.expression === 'string' && typeof h.result === 'string' && Number.isFinite(h.raw)).slice(0, 60);
      if (Number.isFinite(data.memory)) memory = data.memory;
      if (Number.isFinite(data.answer)) answer = data.answer;
      if (data.angleMode === 'RAD') angleMode = 'RAD';
      if (data.settings) settings = { sound: data.settings.sound === true, accent: data.settings.accent === 'blue' ? 'blue' : 'mint' };
    } catch (_) { /* ignore invalid or unavailable storage */ }
    document.documentElement.dataset.accent = settings.accent;
  }
  function playKeySound() {
    if (!settings.sound) return;
    try {
      const Context = window.AudioContext || window.webkitAudioContext;
      if (!Context) return;
      audioContext = audioContext || new Context();
      if (audioContext.state === 'suspended') audioContext.resume();
      const oscillator = audioContext.createOscillator(), gain = audioContext.createGain();
      oscillator.type = 'sine'; oscillator.frequency.value = 620;
      gain.gain.setValueAtTime(0.025, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.045);
      oscillator.connect(gain); gain.connect(audioContext.destination);
      oscillator.start(); oscillator.stop(audioContext.currentTime + 0.05);
    } catch (_) { /* audio is optional */ }
  }

  const nativeAvailable = () => typeof window.NovaNative !== 'undefined';
  const setStatus = (message, error = false) => {
    statusEl.textContent = message;
    statusEl.style.color = error ? '#ff8797' : '#b0c0d8';
  };
  const setExpression = (value) => {
    expression = String(value);
    expressionEl.textContent = expression || '0';
    expressionEl.scrollTop = expressionEl.scrollHeight;
  };
  const normalize = (s) => String(s)
    .replace(/×/g, '*').replace(/÷/g, '/').replace(/[−–]/g, '-')
    .replace(/π/g, 'pi').replace(/√/g, 'sqrt').replace(/,/g, ',');

  function tokenize(input) {
    const s = normalize(input);
    const out = [];
    let i = 0;
    while (i < s.length) {
      const c = s[i];
      if (/\s/.test(c)) { i++; continue; }
      if (/[0-9.]/.test(c)) {
        let j = i;
        while (j < s.length && /[0-9.]/.test(s[j])) j++;
        if (s.slice(i, j).split('.').length > 2) throw new Error('Nombre décimal invalide');
        if ((s[j] === 'e' || s[j] === 'E') && /[+\-0-9]/.test(s[j + 1] || '')) {
          j++;
          if (s[j] === '+' || s[j] === '-') j++;
          const expStart = j;
          while (j < s.length && /[0-9]/.test(s[j])) j++;
          if (expStart === j) throw new Error('Exposant invalide');
        }
        const n = Number(s.slice(i, j));
        if (!Number.isFinite(n)) throw new Error('Nombre non valide');
        out.push({ type: 'number', value: n }); i = j; continue;
      }
      if (/[a-zA-Z_]/.test(c)) {
        let j = i + 1;
        while (j < s.length && /[a-zA-Z_0-9]/.test(s[j])) j++;
        out.push({ type: 'ident', value: s.slice(i, j).toLowerCase() }); i = j; continue;
      }
      if ('+-*/^!%(),'.includes(c)) {
        out.push({ type: c === '(' || c === ')' || c === ',' ? c : 'op', value: c }); i++; continue;
      }
      throw new Error(`Symbole inconnu : ${c}`);
    }
    // Multiplication implicite : 2π, 3(4+1), (2)(3), 2sin(30).
    const functions = new Set(['sin','cos','tan','asin','acos','atan','atan2','sinh','cosh','tanh','asinh','acosh','atanh','ln','log','log2','sqrt','cbrt','abs','exp','floor','ceil','round','trunc','sign','factorial','fact','prime','isprime','gcd','pgcd','lcm','ppcm','hypot','ncr','npr','min','max','pow','root','mod','deg','rad']);
    const result = [];
    const endsValue = (t) => t && (t.type === 'number' || t.type === ')' || (t.type === 'op' && (t.value === '!' || t.value === '%')) || (t.type === 'ident' && !functions.has(t.value)));
    const startsValue = (t) => t && (t.type === 'number' || t.type === 'ident' || t.type === '(');
    for (let k = 0; k < out.length; k++) {
      const prev = out[k - 1], cur = out[k];
      if (k > 0 && endsValue(prev) && startsValue(cur)) result.push({ type: 'op', value: '*' });
      result.push(cur);
    }
    return result;
  }

  function factorial(x) {
    if (!Number.isInteger(x) || x < 0) throw new Error('n! exige un entier positif ou nul');
    if (x <= 20 && nativeAvailable()) {
      const n = window.NovaNative.factorial(String(x));
      if (n !== 'ERREUR') return Number(n);
    }
    if (x > 170) throw new Error('Résultat trop grand pour ce mode numérique');
    let v = 1;
    for (let n = 2; n <= x; n++) v *= n;
    return v;
  }
  function prime(x) {
    if (!Number.isSafeInteger(x)) throw new Error('prime(n) exige un entier sûr');
    if (x > 1e12) throw new Error('Nombre trop grand pour le test de primalité');
    if (nativeAvailable()) {
      const n = window.NovaNative.isPrime(String(x));
      if (n !== 'ERREUR') return Number(n);
    }
    if (x < 2) return 0;
    for (let i = 2; i <= x / i; i++) if (x % i === 0) return 0;
    return 1;
  }
  function gcd(a, b) {
    if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b)) throw new Error('pgcd(a,b) exige deux entiers sûrs');
    if (nativeAvailable()) { const v = window.NovaNative.gcd(String(a), String(b)); if (v !== 'ERREUR') return Number(v); }
    a = Math.abs(a); b = Math.abs(b);
    while (b) { const r = a % b; a = b; b = r; }
    return a;
  }
  function lcm(a, b) {
    if (!Number.isSafeInteger(a) || !Number.isSafeInteger(b)) throw new Error('ppcm(a,b) exige deux entiers sûrs');
    if (nativeAvailable()) { const v = window.NovaNative.lcm(String(a), String(b)); if (v !== 'ERREUR' && Number.isSafeInteger(Number(v))) return Number(v); }
    if (!a || !b) return 0;
    const v = Math.abs((a / gcd(a, b)) * b);
    if (!Number.isSafeInteger(v)) throw new Error('PPCM trop grand');
    return v;
  }
  function hypot(a, b) {
    if (nativeAvailable()) { const v = window.NovaNative.hypot(String(a), String(b)); if (v !== 'ERREUR' && Number.isFinite(Number(v))) return Number(v); }
    return Math.hypot(a, b);
  }
  function combination(n, r, permutation) {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(r) || n < 0 || r < 0 || r > n) throw new Error('nCr/nPr : vérifier n et r');
    r = permutation ? r : Math.min(r, n - r);
    if (r > 170) throw new Error('Résultat trop grand');
    let v = 1;
    for (let i = 1; i <= r; i++) {
      v = permutation ? v * (n - i + 1) : v * ((n - i + 1) / i);
      if (!Number.isFinite(v)) throw new Error('Résultat trop grand');
    }
    if (!Number.isFinite(v)) throw new Error('Résultat trop grand');
    return v;
  }

  const toRadians = (x) => angleMode === 'DEG' ? x * Math.PI / 180 : x;
  const fromRadians = (x) => angleMode === 'DEG' ? x * 180 / Math.PI : x;
  function callFunction(name, args) {
    const x = args[0], y = args[1];
    switch (name) {
      case 'sin': return Math.sin(toRadians(x));
      case 'cos': return Math.cos(toRadians(x));
      case 'tan': return Math.tan(toRadians(x));
      case 'asin': return fromRadians(Math.asin(x));
      case 'acos': return fromRadians(Math.acos(x));
      case 'atan': return fromRadians(Math.atan(x));
      case 'atan2': return fromRadians(Math.atan2(x, y));
      case 'sinh': return Math.sinh(x); case 'cosh': return Math.cosh(x); case 'tanh': return Math.tanh(x);
      case 'asinh': return Math.asinh(x); case 'acosh': return Math.acosh(x); case 'atanh': return Math.atanh(x);
      case 'ln': return Math.log(x); case 'log': return Math.log10(x); case 'log2': return Math.log2(x);
      case 'sqrt': return Math.sqrt(x); case 'cbrt': return Math.cbrt(x); case 'abs': return Math.abs(x);
      case 'exp': return Math.exp(x); case 'floor': return Math.floor(x); case 'ceil': return Math.ceil(x);
      case 'round': return Math.round(x); case 'trunc': return Math.trunc(x); case 'sign': return Math.sign(x);
      case 'factorial': case 'fact': return factorial(x); case 'prime': case 'isprime': return prime(x);
      case 'gcd': case 'pgcd': return gcd(x, y); case 'lcm': case 'ppcm': return lcm(x, y);
      case 'hypot': return hypot(x, y); case 'ncr': return combination(x, y, false); case 'npr': return combination(x, y, true);
      case 'min': return Math.min(...args); case 'max': return Math.max(...args); case 'pow': return Math.pow(x, y);
      case 'root': return x < 0 && Number.isInteger(y) && Math.abs(y % 2) === 1 ? -Math.pow(-x, 1 / y) : Math.pow(x, 1 / y); case 'mod': return x % y; case 'deg': return x * 180 / Math.PI; case 'rad': return x * Math.PI / 180;
      default: throw new Error(`Fonction inconnue : ${name}`);
    }
  }

  function parse(input) {
    const tokens = tokenize(input);
    if (!tokens.length) throw new Error('Saisis une expression');
    let pos = 0;
    const peek = () => tokens[pos];
    const take = () => tokens[pos++];
    const expect = (type, value) => {
      const t = take();
      if (!t || t.type !== type || (value !== undefined && t.value !== value)) throw new Error('Parenthèses ou arguments incomplets');
      return t;
    };
    const constants = { pi: Math.PI, e: Math.E, ans: answer, phi: (1 + Math.sqrt(5)) / 2 };
    const prec = (op) => op === '+' || op === '-' ? 1 : op === '*' || op === '/' ? 2 : op === '^' ? 4 : -1;

    function prefix() {
      const t = take();
      if (!t) throw new Error('Expression incomplète');
      if (t.type === 'number') return t.value;
      if (t.type === 'op' && (t.value === '+' || t.value === '-')) {
        const v = expr(3);
        return t.value === '-' ? -v : v;
      }
      if (t.type === '(') { const v = expr(0); expect(')'); return v; }
      if (t.type === 'ident') {
        if (peek() && peek().type === '(') {
          take();
          const args = [];
          if (!peek() || peek().type !== ')') {
            while (true) {
              args.push(expr(0));
              if (peek() && peek().type === ',') { take(); continue; }
              break;
            }
          }
          expect(')');
          return callFunction(t.value, args);
        }
        if (Object.prototype.hasOwnProperty.call(constants, t.value)) return constants[t.value];
        throw new Error(`Nom inconnu : ${t.value}`);
      }
      throw new Error('Expression invalide');
    }
    function expr(minPrec) {
      let left = prefix();
      while (peek()) {
        const t = peek();
        if (t.type === 'op' && (t.value === '!' || t.value === '%')) {
          take(); left = t.value === '!' ? factorial(left) : left / 100; continue;
        }
        if (t.type !== 'op') break;
        const p = prec(t.value);
        if (p < minPrec) break;
        take();
        const right = expr(t.value === '^' ? p : p + 1);
        if (t.value === '+') left += right;
        else if (t.value === '-') left -= right;
        else if (t.value === '*') left *= right;
        else if (t.value === '/') { if (right === 0) throw new Error('Division par zéro'); left /= right; }
        else if (t.value === '^') left = Math.pow(left, right);
      }
      return left;
    }
    const value = expr(0);
    if (pos !== tokens.length) throw new Error('Expression non terminée');
    if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error('Résultat indéfini dans les nombres réels');
    return value;
  }

  function formatNumber(n) {
    if (!Number.isFinite(n)) return 'Erreur';
    if (Object.is(n, -0)) n = 0;
    if (Number.isInteger(n) && Math.abs(n) < 1e15) return String(n);
    if (Math.abs(n) >= 1e12 || (Math.abs(n) > 0 && Math.abs(n) < 1e-8)) return n.toExponential(8).replace(/\.?0+e/, 'e').replace('e+', 'e');
    return String(Number(n.toPrecision(12)));
  }

  function evaluate() {
    try {
      const input = expression;
      const value = parse(input);
      lastResult = value; answer = value;
      resultEl.textContent = formatNumber(value);
      setStatus('Calcul terminé · Ans mis à jour');
      history.unshift({ expression: input, result: formatNumber(value), raw: value });
      history = history.slice(0, 60);
      saveState();
    } catch (error) {
      setStatus(error && error.message ? error.message : 'Expression invalide', true);
    }
  }

  function insert(value) {
    if (!expression) setExpression(value);
    else if (expression === '0' && /^\d$/.test(value)) setExpression(value);
    else if (expression === '0' && value === '.') setExpression('0.');
    else setExpression(expression + value);
    setStatus('');
  }
  function deleteLast() { setExpression(expression.slice(0, -1)); setStatus(''); }
  function setAngle(mode) {
    angleMode = mode;
    angleChip.textContent = mode;
    document.querySelectorAll('[data-angle]').forEach((b) => { b.classList.toggle('active', b.dataset.angle === mode); b.setAttribute('aria-pressed', String(b.dataset.angle === mode)); });
    saveState();
    setStatus(`Unité d’angle : ${mode}`);
  }
  function updateMemory() { memoryIndicator.textContent = `M: ${memory === null ? '—' : formatNumber(memory)}`; saveState(); }

  function syncShift() {
    document.querySelectorAll('[data-normal]').forEach((b) => {
      b.textContent = shifted ? (b.dataset.shift || b.dataset.normal) : b.dataset.normal;
    });
    document.querySelector('[data-action="shift"]').classList.toggle('shift-active', shifted);
    document.querySelector('[data-action="shift"]').setAttribute('aria-pressed', String(shifted));
    setStatus(shifted ? 'SHIFT activé' : '');
  }

  function openModal(title, html) {
    if (modalBackdrop.classList.contains('hidden')) returnFocus = document.activeElement;
    modalTitle.textContent = title;
    modalBody.innerHTML = html;
    modalBackdrop.classList.remove('hidden');
    $('closeModal').focus();
  }
  function closeModal() { modalBackdrop.classList.add('hidden'); if (returnFocus) returnFocus.focus(); }
  function showSettings() {
    openModal('Réglages', `<div class="settings-list">
      <label class="setting-row"><span><strong>Son des touches</strong><small>Un son discret à chaque pression</small></span><input id="soundSetting" type="checkbox" ${settings.sound ? 'checked' : ''}></label>
      <label class="setting-row"><span><strong>Couleur d’accent</strong><small>Personnalise les commandes principales</small></span><select id="accentSetting"><option value="mint">Menthe</option><option value="blue">Bleu</option></select></label>
      <p class="modal-note">Les réglages et l’historique restent sur cet appareil. Aucun compte ni connexion ne sont nécessaires.</p></div>`);
    $('accentSetting').value = settings.accent;
    $('soundSetting').addEventListener('change', e => { settings.sound = e.target.checked; saveState(); playKeySound(); });
    $('accentSetting').addEventListener('change', e => { settings.accent = e.target.value; document.documentElement.dataset.accent = settings.accent; saveState(); });
  }
  function showTools() {
    openModal('Outils avancés', `
      <div class="tool-grid">
        <button class="tool-card" data-tool="matrix"><div class="tool-icon">▦</div><strong>Matrices</strong><span>Déterminants 2×2 ou 3×3</span></button>
        <button class="tool-card" data-tool="complex"><div class="tool-icon">ℂ</div><strong>Nombres complexes</strong><span>Module et argument de a + bi</span></button>
        <button class="tool-card" data-tool="constants"><div class="tool-icon">π</div><strong>Constantes</strong><span>π, e, φ et fonctions utiles</span></button>
        <button class="tool-card" data-tool="native"><div class="tool-icon">⌘</div><strong>Moteurs natifs</strong><span>Diagnostics C/C++ et Rust</span></button>
      </div>
      <div class="modal-note">Les calculs se font localement. Les outils natifs utilisent Kotlin/JNI, C/C++ et Rust ; le moteur d’expression est en JavaScript.</div>`);
  }
  function showMatrix() {
    openModal('Déterminant de matrice', `
      <div class="tool-form"><p>Choisis une matrice carrée et saisis les coefficients, ligne par ligne.</p>
      <label class="tool-field">Dimension<select id="matrixSize"><option value="2">2 × 2</option><option value="3">3 × 3</option></select></label>
      <div id="matrixInputs" class="field-row"></div>
      <button id="matrixCompute" class="primary-action">CALCULER LE DÉTERMINANT</button>
      <div id="matrixResult" class="tool-result">det(A) = —</div></div>`);
    const renderInputs = () => {
      const n = Number($('matrixSize').value);
      $('matrixInputs').style.gridTemplateColumns = `repeat(${n},minmax(0,1fr))`;
      $('matrixInputs').innerHTML = Array.from({length:n*n}, (_,i) => `<label class="tool-field"><span>a${Math.floor(i/n)+1}${i%n+1}</span><input inputmode="decimal" id="m${i}" value="${i % (n+1) === 0 ? '1' : '0'}"></label>`).join('');
    };
    renderInputs();
    $('matrixSize').addEventListener('change', renderInputs);
    $('matrixCompute').addEventListener('click', () => {
      const n = Number($('matrixSize').value);
      const v = Array.from({length:n*n}, (_,i) => Number($(`m${i}`).value));
      if (v.some(x => !Number.isFinite(x))) { $('matrixResult').textContent = 'Valeur invalide'; return; }
      const det = n === 2 ? v[0]*v[3]-v[1]*v[2] : v[0]*(v[4]*v[8]-v[5]*v[7])-v[1]*(v[3]*v[8]-v[5]*v[6])+v[2]*(v[3]*v[7]-v[4]*v[6]);
      $('matrixResult').textContent = `det(A) = ${formatNumber(det)}`;
    });
  }
  function showComplex() {
    openModal('Nombres complexes', `
      <div class="tool-form"><p>Pour z = a + bi, calcule le module |z| et l’argument principal selon l’unité d’angle active.</p>
      <div class="field-row"><label class="tool-field">Partie réelle a<input id="complexReal" inputmode="decimal" value="3"></label><label class="tool-field">Partie imaginaire b<input id="complexImag" inputmode="decimal" value="4"></label></div>
      <button id="complexCompute" class="primary-action">CALCULER</button><div id="complexResult" class="tool-result">|z| = 5</div></div>`);
    $('complexCompute').addEventListener('click', () => {
      const a = Number($('complexReal').value), b = Number($('complexImag').value);
      if (!Number.isFinite(a) || !Number.isFinite(b)) { $('complexResult').textContent = 'Valeur invalide'; return; }
      const mod = hypot(a,b), arg = angleMode === 'DEG' ? Math.atan2(b,a)*180/Math.PI : Math.atan2(b,a);
      $('complexResult').textContent = `|z| = ${formatNumber(mod)} · arg(z) = ${formatNumber(arg)} ${angleMode === 'DEG' ? '°' : 'rad'}`;
    });
  }
  function showConstants() {
    openModal('Référence rapide', `<div class="tool-form">
      <p><b>Constantes</b> · pi (π), e (Euler), phi (φ), ans (dernier résultat).</p>
      <p><b>Trigonométrie</b> · sin, cos, tan, asin, acos, atan, sinh, cosh, tanh.</p>
      <p><b>Analyse</b> · ln, log, log2, exp, sqrt, cbrt, abs, floor, ceil, round.</p>
      <p><b>Combinatoire</b> · nCr(n,r), nPr(n,r), factorial(n), n!</p>
      <p><b>Arithmétique</b> · prime(n), gcd(a,b), lcm(a,b), mod(a,b), hypot(a,b).</p>
      <p><b>Syntaxe</b> · utilise * pour multiplier si besoin, ^ pour la puissance et la virgule pour séparer les arguments d’une fonction.</p>
      <button id="insertExample" class="primary-action">INSÉRER UN EXEMPLE : nCr(10,3)</button>
    </div>`);
    $('insertExample').addEventListener('click', () => { setExpression('nCr(10,3)'); closeModal(); setStatus('Exemple prêt'); });
  }
  function showNative() {
    let nativeText = 'Mode navigateur : les équivalents JavaScript sont utilisés.';
    if (nativeAvailable()) { try { nativeText = window.NovaNative.engineStatus(); } catch (_) {} }
    openModal('Moteurs de calcul', `<div class="tool-form">
      <p><b>Kotlin</b> · cycle de vie Android, WebView et pont JNI.</p>
      <p><b>JavaScript</b> · analyse sûre des expressions, trigonométrie et matrices.</p>
      <p><b>C/C++</b> · factorielle entière jusqu’à 20! et test de primalité.</p>
      <p><b>Rust</b> · PGCD, PPCM avec contrôle de débordement, hypoténuse.</p>
      <div class="tool-result">${nativeAvailable() ? '●' : '○'} ${nativeText}</div>
      <div class="modal-note">Les fonctions natives concernent des opérations ciblées. Si l’APK est lancée dans un navigateur pour prévisualiser l’interface, les fonctions JavaScript de secours sont utilisées.</div>
    </div>`);
  }
  function showHistory() {
    const html = history.length ? `<div class="history-list">${history.map((h,i)=>`<button class="history-item" data-history="${i}"><span>${escapeHTML(h.expression || '—')}</span><b>${escapeHTML(h.result)}</b></button>`).join('')}</div>` : '<div class="empty-state">Aucun calcul enregistré pour le moment.</div>';
    openModal('Historique des calculs', html);
    modalBody.querySelectorAll('[data-history]').forEach((b) => b.addEventListener('click', () => {
      const h = history[Number(b.dataset.history)];
      if (h) { setExpression(h.expression); resultEl.textContent = h.result; lastResult = h.raw; answer = h.raw; }
      closeModal();
    }));
  }
  function escapeHTML(s) { return String(s).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  document.querySelectorAll('[data-insert]').forEach((button) => {
    button.addEventListener('click', () => {
      let value = button.dataset.insert;
      const normal = button.dataset.normal;
      if (shifted && button.dataset.shiftinsert) value = button.dataset.shiftinsert;
      if (normal === 'x²' || normal === 'x³') {
        if (expression) setExpression(expression + value);
        else setExpression('Ans' + value);
      } else if (normal === 'xʸ') {
        if (shifted && button.dataset.shiftinsert === 'root(') setExpression('root(' + expression + ',');
        else insert(value);
      } else if (shifted && button.dataset.shift === 'nCr') {
        setExpression('nCr(' + (expression || 'Ans') + ',');
      } else if (normal === 'nCr') {
        setExpression(expression + 'nCr(');
      } else insert(value);
      if (shifted && button.dataset.normal) { shifted = false; syncShift(); }
    });
  });

  document.querySelectorAll('[data-action]').forEach((button) => {
    button.addEventListener('click', () => {
      switch (button.dataset.action) {
        case 'clear': setExpression(''); resultEl.textContent = '0'; setStatus('Effacé'); break;
        case 'delete': deleteLast(); break;
        case 'evaluate': evaluate(); break;
        case 'ans': insert('Ans'); break;
        case 'shift': shifted = !shifted; syncShift(); break;
        case 'sign': if (expression) setExpression(`-(${expression})`); else setExpression('-'); break;
        case 'memory-add': try { memory = (memory || 0) + parse(expression || String(answer)); updateMemory(); setStatus('Ajouté à la mémoire'); } catch(e) { setStatus(e.message, true); } break;
        case 'memory-sub': try { memory = (memory || 0) - parse(expression || String(answer)); updateMemory(); setStatus('Soustrait de la mémoire'); } catch(e) { setStatus(e.message, true); } break;
        case 'memory-recall': if (memory !== null) insert(String(memory)); else setStatus('Mémoire vide'); break;
        case 'memory-clear': memory = null; updateMemory(); setStatus('Mémoire effacée'); break;
      }
    });
  });

  document.querySelectorAll('[data-angle]').forEach((b) => b.addEventListener('click', () => setAngle(b.dataset.angle)));
  $('openTools').addEventListener('click', showTools);
  $('openSettings').addEventListener('click', showSettings);
  document.addEventListener('click', e => { if (e.target.closest('button')) playKeySound(); });
  $('openHistory').addEventListener('click', showHistory);
  $('closeModal').addEventListener('click', closeModal);
  modalBackdrop.addEventListener('click', (e) => { if (e.target === modalBackdrop) closeModal(); });
  $('clearHistory').addEventListener('click', () => { if (!history.length) { setStatus('Historique déjà vide'); return; } if (window.confirm('Effacer tout l’historique des calculs ?')) { history = []; saveState(); setStatus('Historique effacé'); } });
  modalBody.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-tool]'); if (!btn) return;
    if (btn.dataset.tool === 'matrix') showMatrix();
    if (btn.dataset.tool === 'complex') showComplex();
    if (btn.dataset.tool === 'constants') showConstants();
    if (btn.dataset.tool === 'native') showNative();
  });
  document.addEventListener('keydown', (e) => {
    if (!modalBackdrop.classList.contains('hidden')) {
      if (e.key === 'Escape') { e.preventDefault(); closeModal(); }
      else if (e.key === 'Tab') {
        const focusable = [...modalBackdrop.querySelectorAll('button, input, select, [tabindex="0"]')].filter(el => !el.disabled);
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
      return;
    }
    if ((e.key === 'Enter' || e.key === ' ') && e.target.closest && e.target.closest('button')) return;
    if (/^[0-9.]$/.test(e.key)) insert(e.key);
    else if (e.key === '+') insert('+');
    else if (e.key === '-') insert('−');
    else if (e.key === '*') insert('×');
    else if (e.key === '/') { e.preventDefault(); insert('÷'); }
    else if (e.key === '^' || e.key === '(' || e.key === ')' || e.key === '%') insert(e.key);
    else if (e.key === 'Enter' || e.key === '=') { e.preventDefault(); evaluate(); }
    else if (e.key === 'Backspace') deleteLast();
    else if (e.key === 'Escape') { setExpression(''); resultEl.textContent = '0'; }
  });

  restoreState();
  setAngle(angleMode);
  syncShift();
  updateMemory();
  setExpression('');
  if (nativeAvailable()) {
    try { $('nativeStatus').textContent = window.NovaNative.engineStatus(); }
    catch (_) { $('nativeStatus').textContent = '4 moteurs prêts'; }
  } else {
    $('nativeStatus').textContent = 'Aperçu web';
    $('engineBadge').innerHTML = '<i></i> MODE APERÇU';
  }
})();
