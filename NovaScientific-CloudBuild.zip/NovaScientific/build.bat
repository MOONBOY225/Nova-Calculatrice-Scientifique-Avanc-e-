@echo off
setlocal
cd /d "%~dp0"
echo =====================================
echo   NOVA SCIENTIFIC - BUILD ANDROID
echo =====================================
where java >nul 2>nul || (echo ERREUR: Java/JDK 17 ou plus est requis.& exit /b 1)
where rustup >nul 2>nul || (echo ERREUR: installe Rust via rustup.rs puis relance ce script.& exit /b 1)
where cargo >nul 2>nul || (echo ERREUR: Cargo est introuvable. Reinstalle Rust avec rustup.& exit /b 1)
where cargo-ndk >nul 2>nul || (echo ERREUR: cargo-ndk manque. Execute: cargo install cargo-ndk& exit /b 1)
where adb >nul 2>nul && echo ADB detecte.
echo Compilation de la bibliotheque Rust et de l'APK...
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo.
  echo ECHEC: consulte README_FR.md section Compilation et verifie Android SDK, NDK, CMake et Rust.
  exit /b 1
)
echo.
echo SUCCES. APK : app\build\outputs\apk\debug\app-debug.apk
exit /b 0
