@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
cd /d "%ROOT%"
set "GRADLE_HOME_MANUAL=%USERPROFILE%\.gradle\nova-gradle\gradle-8.9"
set "GRADLE_EXE=%GRADLE_HOME_MANUAL%\bin\gradle.bat"
if not exist "%GRADLE_EXE%" (
  echo [Nova] Gradle 8.9 n'est pas encore present. Telechargement via PowerShell...
  set "GRADLE_ZIP=%TEMP%\nova-gradle-8.9-bin.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $dest=Join-Path $env:USERPROFILE '.gradle\nova-gradle'; New-Item -ItemType Directory -Force -Path $dest | Out-Null; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $env:TEMP\nova-gradle-8.9-bin.zip; Expand-Archive -LiteralPath $env:TEMP\nova-gradle-8.9-bin.zip -DestinationPath $dest -Force"
  if errorlevel 1 (
    echo ERREUR: impossible de telecharger Gradle. Installe Gradle 8.9 ou verifie la connexion.
    exit /b 1
  )
)
call "%GRADLE_EXE%" %*
exit /b %ERRORLEVEL%
